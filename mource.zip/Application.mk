APP_ABI := arm64-v8a
APP_PLATFORM := android-29
APP_STL := c++_static
APP_CPPFLAGS := -std=c++20
