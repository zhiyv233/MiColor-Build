LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := vendor.xiaomi.hardware.displayfeature_aidl-service
LOCAL_SRC_FILES := \
    src/main.cpp \
    src/color_state.cpp \
    src/displayfeature_service.cpp \
    src/hbm_controller.cpp \
    src/surfaceflinger_backend.cpp
LOCAL_C_INCLUDES := $(LOCAL_PATH)/include
LOCAL_CPPFLAGS := -std=c++20 -Wall -Wextra -Werror -fvisibility=hidden -ffunction-sections -fdata-sections
LOCAL_LDFLAGS := -Wl,--gc-sections -Wl,-z,relro,-z,now
LOCAL_LDLIBS := -lbinder_ndk -llog
include $(BUILD_EXECUTABLE)
