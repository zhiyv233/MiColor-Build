#include "micolor/hbm_policy.h"

using micolor::HbmControlMode;
using micolor::chooseHbmBacklightTarget;

int main() {
    // Production modes never override framework-selected HDR brightness.
    static_assert(chooseHbmBacklightTarget(HbmControlMode::kMonitor, 1303, 4095) == -1);
    static_assert(
            chooseHbmBacklightTarget(HbmControlMode::kFrameworkOwned, 1303, 4095) == -1);
    static_assert(chooseHbmBacklightTarget(HbmControlMode::kFrameworkOwned, 63, 4095) == -1);

    // Only the explicit diagnostic mode may write peak backlight.
    static_assert(chooseHbmBacklightTarget(HbmControlMode::kForcePeak, 1303, 4095) == 4095);
    static_assert(chooseHbmBacklightTarget(HbmControlMode::kForcePeak, 4095, 4095) == -1);
    static_assert(chooseHbmBacklightTarget(HbmControlMode::kForcePeak, -1, 4095) == -1);
    static_assert(chooseHbmBacklightTarget(HbmControlMode::kForcePeak, 1303, -1) == -1);
    return 0;
}
