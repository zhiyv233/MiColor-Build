#include "micolor/color_state.h"

#include <cassert>
#include <cmath>
#include <cstdint>

namespace {

bool near(float a, float b) { return std::fabs(a - b) < 0.001f; }

}  // namespace

int main() {
    micolor::ColorState state;
    auto render = state.render();
    assert(near(render.matrix[0], 1.0f));
    assert(near(render.matrix[5], 1.0f));
    assert(near(render.matrix[10], 1.0f));
    assert(near(render.saturation, 1.0f));

    assert(state.setFeature(0, 23, static_cast<int32_t>(0xffffefdfU), 255) ==
           micolor::UpdateResult::kChanged);
    render = state.render();
    assert(near(render.matrix[0], 1.0f));
    assert(near(render.matrix[5], 239.0f / 255.0f));
    assert(near(render.matrix[10], 223.0f / 255.0f));

    assert(state.setFeature(0, 3, 255, 255) == micolor::UpdateResult::kChanged);
    render = state.render();
    assert(near(render.matrix[5], (239.0f / 255.0f) * (225.0f / 255.0f)));
    assert(near(render.matrix[10], (223.0f / 255.0f) * (140.0f / 255.0f)));

    assert(state.setFeature(0, 3, 50, 255) == micolor::UpdateResult::kChanged);
    render = state.render();
    assert(near(render.matrix[5], (239.0f / 255.0f) * (250.0f / 255.0f)));
    assert(near(render.matrix[10], (223.0f / 255.0f) * (235.0f / 255.0f)));

    assert(state.setFeature(0, 31, 2, 255) == micolor::UpdateResult::kChanged);
    assert(state.paperColorType() == 2);
    assert(near(state.render().saturation, 0.0f));
    assert(state.setFeature(0, 2, 1, 255) == micolor::UpdateResult::kUnchanged);
    assert(state.setFeature(0, 31, 1, 255) == micolor::UpdateResult::kChanged);
    assert(near(state.render().saturation, 1.3f * 0.3f));
    assert(state.setFeature(0, 31, 0, 255) == micolor::UpdateResult::kChanged);
    assert(near(state.render().saturation, 1.3f));

    assert(state.setFeature(0, 3, 0, 255) == micolor::UpdateResult::kChanged);
    assert(state.eyeCareLevel() == 0);
    assert(state.setFeature(0, 23, 2, 255) == micolor::UpdateResult::kChanged);
    assert(state.setFeature(0, 54, 1, (2 << 16) | 1320) ==
           micolor::UpdateResult::kChanged);
    assert(state.rhythmicEyeCareEnabled());
    assert(state.rhythmicCategory() == 2);
    assert(state.rhythmicMinute() == 1320);
    render = state.render();
    assert(near(render.matrix[5], 0.96f));
    assert(near(render.matrix[10], 0.84f));
    assert(state.setFeature(0, 54, 0, (2 << 16) | 1320) ==
           micolor::UpdateResult::kChanged);
    assert(near(state.render().matrix[5], 1.0f));
    assert(near(state.render().matrix[10], 1.0f));
    assert(state.setFeature(0, 54, 1, (3 << 16) | 100) ==
           micolor::UpdateResult::kIgnored);

    micolor::ColorState expert;
    assert(expert.setFeature(0, 26, 1, 0) == micolor::UpdateResult::kReapply);
    assert(expert.expertModeActive());
    assert(near(expert.render().saturation, 1.0f));
    assert(expert.setFeature(0, 26, 2, 0) == micolor::UpdateResult::kChanged);
    assert(near(expert.render().saturation, 1.08f));
    assert(expert.setFeature(0, 26, 3, 0) == micolor::UpdateResult::kChanged);
    assert(near(expert.render().saturation, 0.90f));
    assert(expert.setFeature(0, 26, 128, 2) == micolor::UpdateResult::kChanged);
    assert(near(expert.render().matrix[5], 128.0f / 255.0f));
    assert(expert.setFeature(0, 26, 90, 4) == micolor::UpdateResult::kChanged);
    render = expert.render();
    assert(!near(render.matrix[1], 0.0f));
    assert(!near(render.matrix[2], 0.0f));
    assert(expert.setFeature(0, 26, 50, 5) == micolor::UpdateResult::kChanged);
    assert(near(expert.render().saturation, 0.90f * 1.5f));
    assert(expert.setFeature(0, 26, 64, 6) == micolor::UpdateResult::kChanged);
    assert(expert.setFeature(0, 26, 50, 7) == micolor::UpdateResult::kChanged);
    assert(!near(expert.render().matrix[12], 0.0f));
    assert(expert.setFeature(0, 26, 300, 8) == micolor::UpdateResult::kChanged);
    assert(expert.expertGamma() == 300);
    assert(expert.setFeature(0, 26, 0, 9) == micolor::UpdateResult::kChanged);
    assert(expert.expertGamut() == 0);
    assert(expert.expertGreen() == 255);
    assert(expert.expertHue() == 0);
    assert(expert.expertGamma() == 220);
    assert(expert.setFeature(0, 0, 0, 255) == micolor::UpdateResult::kChanged);
    assert(!expert.expertModeActive());

    micolor::ColorState contrastSafety;
    assert(contrastSafety.setFeature(0, 26, -100, 7) ==
           micolor::UpdateResult::kChanged);
    render = contrastSafety.render();
    assert(near(render.matrix[0], 0.25f));
    assert(near(render.matrix[5], 0.25f));
    assert(near(render.matrix[10], 0.25f));
    assert(near(render.matrix[12], 0.375f));

    micolor::ColorState valueSafety;
    assert(valueSafety.setFeature(0, 26, -255, 6) ==
           micolor::UpdateResult::kChanged);
    render = valueSafety.render();
    assert(near(render.matrix[0], 0.25f));
    assert(near(render.matrix[5], 0.25f));
    assert(near(render.matrix[10], 0.25f));
    assert(near(render.matrix[12], 0.0f));
    assert(valueSafety.setFeature(0, 26, 255, 6) ==
           micolor::UpdateResult::kChanged);
    assert(near(valueSafety.render().matrix[0], 2.0f));
    assert(state.setFeature(0, 24, 0, 262) == micolor::UpdateResult::kReapply);
    assert(state.setFeature(1, 3, 255, 255) ==
           micolor::UpdateResult::kUnsupportedDisplay);
    assert(state.setFeature(0, 23, 0x123456, 255) == micolor::UpdateResult::kIgnored);
    return 0;
}
