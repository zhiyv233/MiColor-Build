# MiColor DisplayFeature HAL

MiColor is a device-independent DisplayFeature service for HyperOS SGSI ports. It replaces the Xiaomi vendor DisplayFeature chain with one auditable native C++ service and translates HyperOS color requests into SurfaceFlinger color transforms.

The implementation does not load Xiaomi or device-vendor display libraries. Its color core contains no model, SoC, panel, DRM, ioctl, private Composer transaction, or OEM Binder dependency. Only the explicit HBM force-peak diagnostic described below can touch device sysfs; normal operation never writes panel sysfs.

中文文档：[README-CN.md](README-CN.md)

## Why It Exists

HyperOS `system_server` expects Xiaomi's Stable AIDL DisplayFeature service even when the system image runs on a non-Xiaomi vendor implementation. The original service normally loads a legacy Xiaomi HAL and a large private display stack. Those libraries are absent or ABI-incompatible on an SGSI target, so the service can register while every display operation fails internally.

MiColor keeps the HyperOS-facing protocol but replaces the implementation below it:

```text
HyperOS Settings / system_server
    -> Stable AIDL v2 setFeature(displayId, mode, value, cookie)
    -> MiColor wire decoder and ColorState
    -> one combined RenderState(matrix + saturation)
    -> SurfaceFlinger Binder transactions 1015 / 1022
    -> standard Composer/HWC path supplied by the target device
```

Device-specific differences remain below SurfaceFlinger instead of leaking into this service.

## AIDL Contract

The service implements the frozen wire ABI directly on the system Binder context:

```text
instance: vendor.xiaomi.hardware.displayfeature_aidl.IDisplayFeature/default
version:  2
hash:     e57e364757bc7b63a3a7e586585c5827115966d7
```

Transactions 1 through 9 preserve their original order, parameter layout, oneway behavior, and compatibility replies. `setFeature`, transaction 7, is the color control entry point. Callback registration supports deduplication, a bounded registry, and Binder death cleanup.

The service deliberately does not expose an extra HIDL, classic Binder, or legacy `hw_get_module` implementation because the analyzed HyperOS client uses this Stable AIDL instance directly.

## Color State Model

HyperOS sends each control as an independent request, but display effects must compose instead of overwriting one another. `ColorState` therefore stores the desired values and renders one atomic snapshot containing:

- color style and color-temperature RGB gains;
- normal and rhythmic eye-care correction;
- paper full-color, pale-color, or monochrome saturation;
- expert gamut, RGB, hue, saturation, value, contrast, and gamma controls.

The snapshot is a 4x4 color matrix plus a saturation scalar. Requests received close together are coalesced for 16 ms and applied serially by one worker, preventing Binder threads from racing or producing partially updated color state.

## Implemented Modes

| Mode | Behavior |
| ---: | --- |
| 0, 1, 2 | HyperOS color styles and style saturation |
| 3 | Eye-care intensity; 50 is the visible minimum and 255 is the maximum endpoint |
| 13, 24 | Reapply the current state after display, wake, HWC, or FPS transitions |
| 23 | Preset or Java signed `0xffRRGGBB` color-temperature input |
| 26 | Complete expert-state protocol described below |
| 31 | Paper color: full `1.0`, pale `0.3`, monochrome `0.0` saturation |
| 32 | Wire-compatible True Tone state; visual no-op without ambient CCT input |
| 54 | Rhythmic eye care using category and virtual minute |

Panel/HWC features such as Game HDR, DC/PWM dimming, AOD brightness, DRE, and opaque game contrast remain diagnostic no-ops. A fixed global matrix cannot implement those features correctly and pretending otherwise could damage display behavior. HDR brightness is not a matrix feature: it is owned by the framework HBM and normal backlight path.

## Expert Mode

Mode 26 uses the following cookies:

| Cookie | Parameter | Input range |
| ---: | --- | ---: |
| 0 | Gamut: enhanced, natural, P3, sRGB | 0..3 |
| 1, 2, 3 | Red, green, blue | 0..255 |
| 4 | Hue | -180..180 |
| 5 | Saturation | -50..100 |
| 6 | Value/brightness | -255..255 |
| 7 | Contrast | -100..100 |
| 8 | Gamma | 170..300 |
| 9 | Restore expert defaults | command |

RGB gains, hue rotation, brightness, contrast, and gamma approximation are composed into the matrix. Gamut and expert saturation contribute to the saturation scalar.

The negative value and contrast ranges have visibility guards. Their minimum UI values map to a `0.25` slope instead of zero, so an accidental endpoint cannot collapse the screen to black or a constant gray-white image. Positive value and contrast retain the `1.0` to `2.0` range.

P3, sRGB, and gamma are deterministic matrix/saturation approximations. Exact calibration requires panel primaries, ICC data, nonlinear transfer functions, or 3D LUT hardware that a device-independent service does not possess. The controls work, but they are not colorimeter-grade gamut calibration.

## Rhythmic Eye Care

Rhythmic eye care is composed from two interfaces:

```text
mode 3:  base eye-care intensity
mode 54: enabled state, cookie=(category << 16) | virtualMinute
category 0/1/2: default, image, reading
```

The missing Xiaomi `librhytheyecare.so` normally supplies proprietary PCC tables. MiColor uses a deterministic smooth day/night curve and category gain. HyperOS already calculates the virtual minute and schedule offset, so the service does not apply the schedule twice.

## SurfaceFlinger Backend

MiColor talks directly to `android.ui.ISurfaceComposer` through Binder:

```text
transaction 1015: set 4x4 color transform
transaction 1022: set saturation
```

No shell command, `/system/bin/service`, `system()`, `dlopen()`, or `dlsym()` is used. Binder status is checked for every transaction. If transaction 1022 is unavailable, saturation is multiplied into the complete 4x4 matrix, including hue mixing and affine offsets, and sent through transaction 1015.

These transaction numbers are HyperOS SurfaceFlinger private APIs, not stable Android SDK APIs. Every supported HyperOS system release must be validated.

## HBM And HDR Peak Brightness

HDR content on HyperOS is handled by the framework's `HighBrightnessModeController` (HBM). A `DisplayDeviceConfig` carrying `highBrightnessMode enabled="true"` supplies the HBM range. `DisplayPowerController` then combines the user's slider, auto-brightness, thermal limits, and HDR/SDR ratio before applying one variable backlight value.

MiColor observes that authoritative framework state for diagnostics:

- It polls `android.hardware.display.IDisplayManager#getBrightnessInfo` (Binder transaction `0x2e`) to observe `BrightnessInfo.highBrightnessMode` (0=off, 1=sunlight, 2=HDR) and the current brightness.
- Mode 0 (monitor): compatibility mode; the HAL never writes the backlight.
- Mode 1 (frameworkOwned, default): `DisplayPowerController` remains the only production backlight writer, including while HDR is active. The brightness slider is therefore preserved across its complete range.
- Mode 2 (forcePeak): bring-up/test mode that unconditionally drives the backlight to the panel maximum.

The mode is selected with `persist.vendor.micolor.hbm.mode` (unset or invalid defaults to `1`). Mode 2 must not be enabled in normal use because it intentionally defeats framework brightness control. Polling is adaptive: 500 ms while HBM is active, 1 s otherwise.

Transaction 1 `notifyBrightness(int)` is also recorded for wire compatibility and diagnostics. It is a notification to vendor display algorithms, not authority to bypass the framework and write the base backlight directly.

## Recovery And Boot Continuity

SurfaceFlinger owns one global color transform, and boot animation, desktop startup, wake-up, HWC reset, Night Light, accessibility color transforms, or HDR transitions may replace it.

MiColor handles known resets in two ways:

- Modes 13 and 24 reapply the latest desired state after display and FPS transitions.
- The first effective color request starts a 20-second boot stabilization window that reapplies the latest state every 50 ms. This covers the boot-animation-to-desktop reset; the window then stops and the service returns to event-driven operation.

The boot replay is bounded and diagnostic counters expose its activity. It is not a permanent polling loop.

## Diagnostics

The Binder dump reports request, ignored-feature, apply, failure, callback, generation, boot-replay, and current color-state values:

```sh
adb shell dumpsys vendor.xiaomi.hardware.displayfeature_aidl.IDisplayFeature/default
```

`desired/applied` generations make coalescing and failed backend updates visible. Unknown modes return wire success for compatibility but are counted and do not mutate color state. The `hbm:` line reports observer mode, framework connection state, observed HBM mode and brightness, current and maximum backlight, last target, and force-mode write/skip counters.

## Build

Platform build:

```sh
m vendor.xiaomi.hardware.displayfeature_aidl-service micolor_color_state_test \
    micolor_hbm_policy_test
```

Standalone arm64 build with Android NDK r27 or newer:

```sh
ndk-build -C hal NDK_PROJECT_PATH=. APP_BUILD_SCRIPT=Android.mk \
    NDK_APPLICATION_MK=Application.mk
```

The standalone configuration targets `arm64-v8a`, Android API 29+, C++20, and static libc++. The platform build is the release integration path; the NDK build is useful for ABI and dependency auditing without a complete AOSP tree.

Run the host state-machine test with either the platform target above or directly:

```sh
g++ -std=c++20 -Wall -Wextra -Werror -Ihal/include \
    hal/src/color_state.cpp hal/tests/color_state_test.cpp \
    -o /tmp/micolor-color-state-test
/tmp/micolor-color-state-test

g++ -std=c++20 -Wall -Wextra -Werror -Ihal/include \
    hal/tests/hbm_policy_test.cpp -o /tmp/micolor-hbm-policy-test
/tmp/micolor-hbm-policy-test
```

## Runtime Dependencies

The service's own glue, state machine, matrix code, worker, and backend are compiled into one ELF. The standalone release directly needs only Android base libraries:

```text
libbinder_ndk.so
liblog.so
libc.so
libm.so
libdl.so
```

It must not link or load Xiaomi DisplayFeature, OEM Composer, panel, DRM, or sensor-control libraries.

## Integration

Install the executable at:

```text
/vendor/bin/hw/vendor.xiaomi.hardware.displayfeature_aidl-service
```

Install the minimal init rc and Stable AIDL v2 VINTF fragment from this directory, then merge the SELinux policy under `sepolicy/`. The service runs as user `system`, groups `system graphics`, and registers on the system Binder ServiceManager.

Use the target device's compiled SELinux type names when integrating the policy. The templates describe required relationships but cannot assume every vendor policy namespace uses identical type names. Validate under Enforcing before release.

HBM observation requires the HAL domain to reach `DisplayManagerService` (service_manager `find` on `display`, plus `binder call` to `system_server`). The default framework-owned mode never writes sysfs. Only the explicit force-peak diagnostic (`persist.vendor.micolor.hbm.mode=2`) additionally requires permission to write the panel backlight node; modes 0 and 1 are read-only.

After the replacement passes boot, Binder, color, wake, and rollback validation, obsolete Xiaomi chain files may be removed:

```text
/vendor/bin/displayfeature
/vendor/lib64/libdisplayfeatureservice.so
/vendor/lib64/libdisplayfeature.so
/vendor/lib64/vendor.xiaomi.hardware.displayfeature@1.0.so
/vendor/lib64/vendor.xiaomi.hardware.displayfeature_aidl-V2-ndk.so
/odm/lib64/hw/displayfeature.default.so
```

Do not remove unrelated Composer, HWC, displayconfig, gralloc, DRM, panel, or SurfaceFlinger libraries. Keep rollback copies until cold boot and display regression testing are complete.

## Portability Limits

The source is independent of a particular device, but successful deployment still requires:

- a HyperOS system build whose SurfaceFlinger accepts transactions 1015 and 1022;
- system Binder visibility between `system_server`, this vendor service, and SurfaceFlinger;
- for HBM diagnostics, the HAL domain must be allowed to query `DisplayManagerService`; only the explicit force-peak bring-up mode also needs panel sysfs write access;
- correct VINTF and SELinux integration;
- testing of global matrix ownership with Night Light, accessibility, HDR, suspend/resume, and SurfaceFlinger restart;
- validation on representative OEM, SoC, Vendor API, and Enforcing SELinux combinations.

The first validated sample proves the architecture on one SGSI device; it does not by itself prove universal compatibility.
