# MiColor DisplayFeature HAL

MiColor 是面向 HyperOS SGSI 移植的设备无关 DisplayFeature 服务。它使用一个可审计的原生 C++ 服务替换小米原有的 DisplayFeature 私有链路，并将 HyperOS 的色彩请求转换为 SurfaceFlinger 色彩变换。

核心实现不加载小米或设备厂商的显示库。色彩核心不包含机型、SoC、面板、DRM、ioctl、私有 Composer transaction 或 OEM Binder 依赖；只有下文显式启用的 HBM 强制峰值诊断模式可能接触设备 sysfs，正常运行不会写面板 sysfs。

English documentation: [README.md](README.md)

## 项目目的

HyperOS `system_server` 即使运行在非小米 Vendor 上，也会查找小米 Stable AIDL DisplayFeature 服务。原服务通常继续加载 legacy 小米 HAL 和大量私有显示库；这些库在 SGSI 目标设备上往往缺失或 ABI 不兼容，导致服务看似注册成功，但所有显示操作都在内部失败。

MiColor 保留 HyperOS 上层所需协议，替换协议以下的实现：

```text
HyperOS 设置 / system_server
    -> Stable AIDL v2 setFeature(displayId, mode, value, cookie)
    -> MiColor wire 解码和 ColorState
    -> 单一组合 RenderState(matrix + saturation)
    -> SurfaceFlinger Binder transaction 1015 / 1022
    -> 目标设备提供的标准 Composer/HWC 路径
```

设备之间的差异留在 SurfaceFlinger 以下，不进入本服务源码。

## AIDL 契约

服务在 system Binder context 上直接实现冻结的 wire ABI：

```text
instance: vendor.xiaomi.hardware.displayfeature_aidl.IDisplayFeature/default
version:  2
hash:     e57e364757bc7b63a3a7e586585c5827115966d7
```

Transaction 1 到 9 保持原顺序、参数布局、oneway 属性和兼容返回。Transaction 7 的 `setFeature` 是色彩控制入口。Callback registry 支持去重、数量限制和 Binder death 清理。

已分析的 HyperOS 客户端直接使用该 Stable AIDL 实例，因此服务不额外暴露 HIDL、classic Binder 或 legacy `hw_get_module` 实现，避免扩大兼容面和冲突风险。

## 色彩状态原理

HyperOS 将每个控件作为独立请求发送，但显示效果必须彼此组合，不能互相覆盖。`ColorState` 保存所有 desired value，并渲染为一个原子快照，其中包括：

- 色彩风格和色温 RGB 增益；
- 普通护眼与节律护眼修正；
- 纸张色彩的全彩、淡彩和黑白 saturation；
- 高级模式的色域、RGB、色相、饱和度、明度、对比度和 Gamma。

最终快照由一个 4x4 color matrix 和一个 saturation 标量组成。短时间内到达的请求会在 16 ms 内合并，并由单一 worker 串行提交，避免 Binder 线程竞争和只应用了一半参数的中间状态。

## 已实现模式

| Mode | 行为 |
| ---: | --- |
| 0、1、2 | HyperOS 色彩风格和风格 saturation |
| 3 | 普通护眼强度；50 为可见最低强度，255 为最大端点 |
| 13、24 | 显示、亮屏、HWC 或 FPS transition 后重放当前状态 |
| 23 | 色温预设或 Java signed `0xffRRGGBB` 输入 |
| 26 | 完整高级模式协议，见下一节 |
| 31 | 纸张色彩：全彩 `1.0`、淡彩 `0.3`、黑白 `0.0` saturation |
| 32 | 保持 True Tone wire 状态；缺少环境 CCT 输入时视觉 no-op |
| 54 | 使用应用 category 和 virtual minute 的节律护眼 |

Game HDR、DC/PWM 调光、AOD 亮度、DRE 和语义不透明的游戏对比度属于面板或 HWC 能力，当前保持可诊断 no-op。固定全局 matrix 无法正确实现这些功能，错误模拟反而可能破坏显示状态。HDR 亮度本身不是 matrix 功能，它由框架 HBM 和标准背光链路负责。

## 高级模式

Mode 26 的 cookie 定义如下：

| Cookie | 参数 | 输入范围 |
| ---: | --- | ---: |
| 0 | 色域：增强、自然、P3、sRGB | 0..3 |
| 1、2、3 | R、G、B | 0..255 |
| 4 | 色相 | -180..180 |
| 5 | 饱和度 | -50..100 |
| 6 | 明度 | -255..255 |
| 7 | 对比度 | -100..100 |
| 8 | Gamma | 170..300 |
| 9 | 恢复高级模式默认值 | 命令 |

RGB 增益、色相旋转、明度、对比度和 Gamma 近似会组合进 matrix；色域和专家饱和度会参与 saturation 标量计算。

明度和对比度的负半轴带有最低可见度围栏。UI 最低值映射为 `0.25` 斜率，而不是零，因此误触端点不会再让屏幕变黑或变成无法辨识的固定灰白画面。正半轴仍保持 `1.0` 到 `2.0` 的范围。

P3、sRGB 和 Gamma 使用确定性的 matrix/saturation 近似。精确校准需要面板原色、ICC 数据、非线性 transfer function 或 3D LUT 硬件，而设备无关服务不具备这些输入。因此控件会真实生效，但不能将其视为色度计级 P3/sRGB 校准。

## 节律护眼

节律护眼由两个接口共同组成：

```text
mode 3:  基础护眼强度
mode 54: enabled，cookie=(category << 16) | virtualMinute
category 0/1/2: 默认、图像、阅读
```

原厂缺失的 `librhytheyecare.so` 通常提供私有 PCC 表。MiColor 使用确定性的平滑昼夜曲线和 category 增益。HyperOS 已经计算 virtual minute 和作息偏移，服务不会重复应用时间偏移。

## SurfaceFlinger 后端

MiColor 通过 Binder 直接调用 `android.ui.ISurfaceComposer`：

```text
transaction 1015: 设置 4x4 color transform
transaction 1022: 设置 saturation
```

服务不执行 shell、不调用 `/system/bin/service`，也不使用 `system()`、`dlopen()` 或 `dlsym()`。每次 Binder transaction 都检查返回状态。如果目标 SurfaceFlinger 不支持 transaction 1022，服务会将 saturation 乘入完整 4x4 matrix，保留色相混合和 affine offset，再通过 transaction 1015 提交。

这些 transaction 编号属于 HyperOS SurfaceFlinger 私有 API，不是稳定 Android SDK API。每个拟支持的 HyperOS System 版本都必须单独验证。

## HBM 与 HDR 峰值亮度

HyperOS 通过框架 `HighBrightnessModeController`（HBM）处理 HDR 内容。携带 `highBrightnessMode enabled="true"` 的 `DisplayDeviceConfig` 提供 HBM 范围，`DisplayPowerController` 再组合用户亮度滑块、自动亮度、温控限制和 HDR/SDR 比例，最后写入一个可变背光值。

MiColor 只观察该权威框架状态，用于诊断：

- 轮询 `android.hardware.display.IDisplayManager#getBrightnessInfo`（Binder transaction `0x2e`），读取 `BrightnessInfo.highBrightnessMode`（0=关闭、1=sunlight、2=HDR）和当前亮度。
- mode 0（monitor）：兼容监视模式，HAL 永不写背光。
- mode 1（frameworkOwned，默认）：包括 HDR 激活期间在内，`DisplayPowerController` 都是唯一的生产背光写入者，因此保留亮度滑块的完整范围。
- mode 2（forcePeak）：bring-up/测试模式，无条件把背光推到面板最大。

模式通过 `persist.vendor.micolor.hbm.mode` 选择（未设置或非法值默认 `1`）。mode 2 会有意绕过框架亮度控制，正常使用时不得启用。轮询是自适应的：HBM 激活时 500 ms，否则 1 s。

AIDL transaction 1 `notifyBrightness(int)` 也会为 wire 兼容和诊断而记录。它是发给厂商显示算法的状态通知，不代表 HAL 可以绕过框架直接写基础背光。

## 状态恢复与启动连续性

SurfaceFlinger 只有一个全局 color transform。开机动画、桌面启动、亮屏、HWC reset、Night Light、无障碍色彩或 HDR transition 都可能覆盖它。

MiColor 使用两种恢复机制：

- Mode 13 和 24 在显示或 FPS transition 后重放最新 desired state。
- 首个有效色彩请求会启动一个 20 秒稳定窗口，每 50 ms 重放最新状态，覆盖开机动画切换桌面时的 matrix 重置；窗口结束后自动恢复事件驱动。

启动重放有明确时间上限，`dumpsys` 会报告执行次数。它不是永久后台轮询。

## 诊断

通过 Binder dump 可查看请求数、忽略模式、apply、failure、callback、generation、启动重放以及当前色彩状态：

```sh
adb shell dumpsys vendor.xiaomi.hardware.displayfeature_aidl.IDisplayFeature/default
```

`desired/applied` generation 可用于识别请求合并和后端失败。未知模式为了 wire 兼容会返回成功，但只计数，不改变色彩状态。`hbm:` 行会报告观察模式、框架连接状态、HBM mode/亮度、当前/最大背光、最后目标以及仅供强制模式使用的 write/skip 计数。

## 构建

Android 平台构建：

```sh
m vendor.xiaomi.hardware.displayfeature_aidl-service micolor_color_state_test \
    micolor_hbm_policy_test
```

使用 Android NDK r27 或更新版本独立构建 arm64：

```sh
ndk-build -C hal NDK_PROJECT_PATH=. APP_BUILD_SCRIPT=Android.mk \
    NDK_APPLICATION_MK=Application.mk
```

独立构建配置目标为 `arm64-v8a`、Android API 29+、C++20 和静态 libc++。平台构建是正式集成路径；NDK 构建用于没有完整 AOSP 源码树时的 ABI 和依赖审计。

可直接运行主机状态机测试：

```sh
g++ -std=c++20 -Wall -Wextra -Werror -Ihal/include \
    hal/src/color_state.cpp hal/tests/color_state_test.cpp \
    -o /tmp/micolor-color-state-test
/tmp/micolor-color-state-test

g++ -std=c++20 -Wall -Wextra -Werror -Ihal/include \
    hal/tests/hbm_policy_test.cpp -o /tmp/micolor-hbm-policy-test
/tmp/micolor-hbm-policy-test
```

## 运行时依赖

自研 glue、状态机、矩阵计算、worker 和后端均编入一个 ELF。独立 release 产物的直接动态依赖只有 Android 基础库：

```text
libbinder_ndk.so
liblog.so
libc.so
libm.so
libdl.so
```

最终服务不得链接或加载小米 DisplayFeature、OEM Composer、面板、DRM 或传感器控制库。

## 集成

服务可执行文件安装到：

```text
/vendor/bin/hw/vendor.xiaomi.hardware.displayfeature_aidl-service
```

同时安装本目录中的最小 init rc 和 Stable AIDL v2 VINTF fragment，并合入 `sepolicy/` 下的策略。服务以 `system` 用户、`system graphics` groups 运行，在 system Binder ServiceManager 注册。

实际集成时必须采用目标设备已编译 SELinux policy 中有效的类型名。目录中的策略是权限关系模板，不能假设所有 Vendor policy namespace 都使用相同类型名。正式发布前必须在 Enforcing 下验证。

观察 HBM 状态需要 HAL domain 能访问 `DisplayManagerService`（service_manager 对 `display` 的 `find`，以及对 `system_server` 的 `binder call`）。默认 framework-owned 模式不会写 sysfs。只有显式强制峰值诊断（`persist.vendor.micolor.hbm.mode=2`）还需要面板背光节点写权限；mode 0 和 mode 1 都是只读模式。

替换服务通过开机、Binder、色彩、息屏亮屏和回滚验证后，可以删除旧小米链路文件：

```text
/vendor/bin/displayfeature
/vendor/lib64/libdisplayfeatureservice.so
/vendor/lib64/libdisplayfeature.so
/vendor/lib64/vendor.xiaomi.hardware.displayfeature@1.0.so
/vendor/lib64/vendor.xiaomi.hardware.displayfeature_aidl-V2-ndk.so
/odm/lib64/hw/displayfeature.default.so
```

不要删除无关的 Composer、HWC、displayconfig、gralloc、DRM、面板或 SurfaceFlinger 库。完成冷启动和显示回归测试前应保留回滚副本。

## 通用性边界

源码本身不依赖具体设备，但成功部署仍要求：

- HyperOS System 的 SurfaceFlinger 接受 transaction 1015 和 1022；
- `system_server`、本 vendor 服务和 SurfaceFlinger 之间具有 system Binder 可见性；
- 若需要 HBM 诊断，HAL domain 必须允许查询 `DisplayManagerService`；只有显式 force-peak bring-up 模式需要面板 sysfs 写权限；
- VINTF 和 SELinux 集成正确；
- 验证与 Night Light、无障碍色彩、HDR、休眠唤醒及 SurfaceFlinger 重启的全局 matrix 所有权；
- 在具有代表性的 OEM、SoC、Vendor API 和 Enforcing SELinux 组合上测试。

首个 SGSI 样本只能证明该架构已在一个设备上成立，不能单独证明所有设备均兼容。
