#pragma once

#include "micolor/color_state.h"

#include <android/binder_ibinder.h>

namespace micolor {

class ColorBackend {
  public:
    virtual ~ColorBackend() = default;
    virtual bool apply(const RenderState& state) = 0;
};

class SurfaceFlingerColorBackend final : public ColorBackend {
  public:
    SurfaceFlingerColorBackend();
    ~SurfaceFlingerColorBackend() override;
    bool apply(const RenderState& state) override;

  private:
    bool transactMatrix(const std::array<float, 16>& matrix);
    bool transactSaturation(float saturation);
    bool connect();
    void disconnect();

    AIBinder* surfaceFlinger_ = nullptr;
};

}  // namespace micolor
