#pragma once

#include "micolor/color_backend.h"
#include "micolor/color_state.h"
#include "micolor/hbm_controller.h"

#include <android/binder_ibinder.h>

#include <chrono>
#include <condition_variable>
#include <cstdint>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

namespace micolor {

class DisplayFeatureService {
  public:
    explicit DisplayFeatureService(std::unique_ptr<ColorBackend> backend);
    ~DisplayFeatureService();

    AIBinder* createBinder();
    binder_status_t transact(transaction_code_t code, const AParcel* input, AParcel* output);
    binder_status_t dump(int fd);

  private:
    struct CallbackEntry;

    void scheduleApply();
    void workerLoop();
    void registerCallback(AIBinder* callback);
    static void callbackDied(void* cookie);

    std::mutex mutex_;
    std::condition_variable condition_;
    HbmController hbm_;
    ColorState state_;
    RenderState pending_;
    std::unique_ptr<ColorBackend> backend_;
    std::vector<std::unique_ptr<CallbackEntry>> callbacks_;
    std::thread worker_;
    bool stopping_ = false;
    bool bootReplayActive_ = false;
    std::chrono::steady_clock::time_point bootReplayDeadline_{};
    uint64_t desiredGeneration_ = 0;
    uint64_t appliedGeneration_ = 0;
    uint64_t requestCount_ = 0;
    uint64_t ignoredFeatureCount_ = 0;
    uint64_t unsupportedDisplayCount_ = 0;
    int32_t lastIgnoredFeature_ = -1;
    uint64_t applyCount_ = 0;
    uint64_t applyFailureCount_ = 0;
    uint64_t bootReplayCount_ = 0;
};

const char* displayFeatureInstance();

}  // namespace micolor
