#pragma once

#include <array>
#include <cstdint>

namespace micolor {

struct RenderState {
    std::array<float, 16> matrix{};
    float saturation = 1.0f;

    bool nearlyEquals(const RenderState& other, float epsilon = 0.0001f) const;
};

enum class UpdateResult {
    kChanged,
    kReapply,
    kUnchanged,
    kIgnored,
    kUnsupportedDisplay,
};

class ColorState {
  public:
    UpdateResult setFeature(int32_t displayId, int32_t caseId, int32_t modeId,
                            int32_t cookie);
    RenderState render() const;

    int32_t colorStyle() const { return colorStyle_; }
    int32_t eyeCareLevel() const { return eyeCareLevel_; }
    int32_t paperColorType() const { return paperColorType_; }
    bool rhythmicEyeCareEnabled() const { return rhythmicEyeCareEnabled_; }
    int32_t rhythmicCategory() const { return rhythmicCategory_; }
    int32_t rhythmicMinute() const { return rhythmicMinute_; }
    bool expertModeActive() const { return expertModeActive_; }
    int32_t expertGamut() const { return expertGamut_; }
    int32_t expertRed() const { return expertRed_; }
    int32_t expertGreen() const { return expertGreen_; }
    int32_t expertBlue() const { return expertBlue_; }
    int32_t expertHue() const { return expertHue_; }
    int32_t expertSaturation() const { return expertSaturation_; }
    int32_t expertValue() const { return expertValue_; }
    int32_t expertContrast() const { return expertContrast_; }
    int32_t expertGamma() const { return expertGamma_; }

  private:
    uint8_t red_ = 255;
    uint8_t green_ = 255;
    uint8_t blue_ = 255;
    int32_t colorStyle_ = 0;
    int32_t eyeCareLevel_ = 0;
    int32_t paperColorType_ = 0;
    bool trueToneEnabled_ = false;
    bool rhythmicEyeCareEnabled_ = false;
    int32_t rhythmicCategory_ = 0;
    int32_t rhythmicMinute_ = 0;
    bool expertModeActive_ = false;
    int32_t expertGamut_ = 0;
    int32_t expertRed_ = 255;
    int32_t expertGreen_ = 255;
    int32_t expertBlue_ = 255;
    int32_t expertHue_ = 0;
    int32_t expertSaturation_ = 0;
    int32_t expertValue_ = 0;
    int32_t expertContrast_ = 0;
    int32_t expertGamma_ = 220;
};

}  // namespace micolor
