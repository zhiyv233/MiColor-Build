#pragma once

#include "micolor/hbm_policy.h"

#include <android/binder_ibinder.h>

#include <atomic>
#include <cstdint>
#include <mutex>
#include <thread>

namespace micolor {

// HBM (high-brightness mode) observer.
//
// HyperOS drives HDR peak brightness in the framework: HighBrightnessModeController
// (DisplayPowerController) computes an HBM brightness once a DisplayDeviceConfig
// carrying highBrightnessMode data is present, and DisplayPowerController applies
// it through the normal backlight path. This controller observes that state for
// diagnostics without competing with DisplayPowerController:
//
//   * It polls the framework's BrightnessInfo (android.hardware.display
//     IDisplayManager#getBrightnessInfo, code 0x2e) to observe the authoritative
//     HBM state (BrightnessInfo.highBrightnessMode) and current brightness.
//   * mode 0 (monitor): compatibility alias for passive monitoring.
//   * mode 1 (frameworkOwned, default): DisplayPowerController remains the only
//     backlight writer. This preserves the brightness slider while HDR is active.
//   * mode 2 (forcePeak): bring-up/test mode that unconditionally drives the
//     backlight to the panel maximum.
//
// The mode is read from the sysprop persist.vendor.micolor.hbm.mode (0/1/2;
// unset defaults to 1). Mode 2 must never be enabled for normal use. Polling is
// adaptive: 500 ms while HBM is active, 1 s otherwise.
class HbmController {
  public:
    using Mode = HbmControlMode;

    HbmController();
    ~HbmController();

    void start();
    void stop();

    // Xiaomi wire inputs (protocol completeness; tx1 notifyBrightness and HDR-
    // relevant setFeature cases are recorded and logged, never blindly applied).
    void onBrightness(int32_t brightness);
    void onSetFeature(int32_t caseId, int32_t modeId, int32_t cookie);

    struct Snapshot {
        Mode mode = Mode::kMonitor;
        bool frameworkConnected = false;
        bool frameworkCallFailed = false;
        int32_t hbmMode = 0;  // BrightnessInfo.HIGH_BRIGHTNESS_MODE_OFF/HDR/SUNLIGHT
        float brightness = 0.0f;
        float brightnessMaximum = 1.0f;
        int32_t backlight = 0;
        int32_t maxBacklight = -1;
        int32_t lastTargetBacklight = -1;
        uint64_t pollCount = 0;
        uint64_t writeCount = 0;
        uint64_t skipCount = 0;
        int32_t lastNotifyBrightness = -1;
        int32_t lastHdrFeatureCase = -1;
        int32_t lastHdrFeatureMode = -1;
    };

    Snapshot snapshot() const;

  private:
    void loop();
    bool refreshFrameworkState();
    void refreshBacklight();
    void writeBacklight(int32_t value);
    Mode readMode() const;
    void bindDisplayManager();
    void unbindDisplayManager();

    std::thread thread_;
    std::atomic<bool> stopping_{false};
    mutable std::mutex mutex_;
    Snapshot state_;
    AIBinder* displayManager_ = nullptr;
};

}  // namespace micolor
