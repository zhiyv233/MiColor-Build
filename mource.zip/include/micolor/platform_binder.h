#pragma once

#include <android/binder_ibinder.h>
#include <android/binder_status.h>

#include <cstddef>
#include <cstdint>

// These service-side APIs are exported by Android's platform libbinder_ndk but
// intentionally omitted from the application NDK headers. Weak declarations
// keep standalone ABI builds possible without bundling a Binder implementation.
extern "C" {

__attribute__((weak)) binder_status_t AServiceManager_addService(AIBinder* binder,
                                                                  const char* instance);
__attribute__((weak)) AIBinder* AServiceManager_checkService(const char* instance);
__attribute__((weak)) void ABinderProcess_setThreadPoolMaxThreadCount(uint32_t numThreads);
__attribute__((weak)) void ABinderProcess_joinThreadPool();
__attribute__((weak)) void AIBinder_markVintfStability(AIBinder* binder);

}
