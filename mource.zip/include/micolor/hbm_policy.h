#pragma once

#include <cstdint>

namespace micolor {

// The framework is the sole owner of production backlight writes. Force-peak
// remains available only as an explicit panel bring-up diagnostic.
enum class HbmControlMode {
    kMonitor = 0,
    kFrameworkOwned = 1,
    kForcePeak = 2,
};

constexpr int32_t chooseHbmBacklightTarget(HbmControlMode mode, int32_t current,
                                           int32_t maximum) {
    if (mode != HbmControlMode::kForcePeak || current < 0 || maximum <= 0 ||
        current == maximum) {
        return -1;
    }
    return maximum;
}

}  // namespace micolor
