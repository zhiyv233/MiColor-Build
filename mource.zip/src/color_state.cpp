#include "micolor/color_state.h"

#include <algorithm>
#include <cmath>

namespace micolor {
namespace {

constexpr int32_t kExpectedCookie = 255;
constexpr float kPi = 3.14159265358979323846f;

using Matrix = std::array<float, 16>;

Matrix identityMatrix() {
    return {1.0f, 0.0f, 0.0f, 0.0f,
            0.0f, 1.0f, 0.0f, 0.0f,
            0.0f, 0.0f, 1.0f, 0.0f,
            0.0f, 0.0f, 0.0f, 1.0f};
}

float get(const Matrix& matrix, size_t row, size_t column) {
    return matrix[column * 4 + row];
}

void set(Matrix& matrix, size_t row, size_t column, float value) {
    matrix[column * 4 + row] = value;
}

Matrix multiply(const Matrix& left, const Matrix& right) {
    Matrix result{};
    for (size_t row = 0; row < 4; ++row) {
        for (size_t column = 0; column < 4; ++column) {
            float value = 0.0f;
            for (size_t k = 0; k < 4; ++k) value += get(left, row, k) * get(right, k, column);
            set(result, row, column, value);
        }
    }
    return result;
}

Matrix channelMatrix(float red, float green, float blue) {
    Matrix result = identityMatrix();
    set(result, 0, 0, red);
    set(result, 1, 1, green);
    set(result, 2, 2, blue);
    return result;
}

Matrix affineMatrix(float scale, float offset) {
    Matrix result = channelMatrix(scale, scale, scale);
    set(result, 0, 3, offset);
    set(result, 1, 3, offset);
    set(result, 2, 3, offset);
    return result;
}

Matrix hueMatrix(int32_t degrees) {
    const float angle = static_cast<float>(degrees) * kPi / 180.0f;
    const float cosine = std::cos(angle);
    const float sine = std::sin(angle);
    constexpr float lr = 0.213f;
    constexpr float lg = 0.715f;
    constexpr float lb = 0.072f;
    Matrix result = identityMatrix();

    set(result, 0, 0, lr + cosine * (1.0f - lr) + sine * -lr);
    set(result, 0, 1, lg + cosine * -lg + sine * -lg);
    set(result, 0, 2, lb + cosine * -lb + sine * (1.0f - lb));
    set(result, 1, 0, lr + cosine * -lr + sine * 0.143f);
    set(result, 1, 1, lg + cosine * (1.0f - lg) + sine * 0.140f);
    set(result, 1, 2, lb + cosine * -lb + sine * -0.283f);
    set(result, 2, 0, lr + cosine * -lr + sine * -(1.0f - lr));
    set(result, 2, 1, lg + cosine * -lg + sine * lg);
    set(result, 2, 2, lb + cosine * (1.0f - lb) + sine * lb);
    return result;
}

float expertGamutSaturation(int32_t gamut) {
    switch (gamut) {
        case 0:  // Enhanced/widest gamut.
            return 1.20f;
        case 2:  // Display P3 approximation.
            return 1.08f;
        case 3:  // sRGB approximation.
            return 0.90f;
        default:  // Natural/calibrated.
            return 1.0f;
    }
}

Matrix gammaMatrix(int32_t gamma) {
    const float exponent = 220.0f / static_cast<float>(gamma);
    const float low = std::pow(0.25f, exponent);
    const float high = std::pow(0.75f, exponent);
    const float scale = (high - low) / 0.5f;
    return affineMatrix(scale, low - scale * 0.25f);
}

float expertContrastScale(int32_t contrast) {
    if (contrast < 0) {
        // Keep the UI minimum distinguishable instead of collapsing every
        // input color to the same middle gray at -100.
        return 1.0f + static_cast<float>(contrast) * 0.0075f;
    }
    return 1.0f + static_cast<float>(contrast) / 100.0f;
}

float expertValueScale(int32_t value) {
    if (value < 0) {
        // Preserve visible image detail at the UI minimum instead of
        // multiplying every RGB channel by zero at -255.
        return 1.0f + static_cast<float>(value) * (0.75f / 255.0f);
    }
    return 1.0f + static_cast<float>(value) / 255.0f;
}

float channelGain(uint8_t value) {
    return static_cast<float>(value == 0 ? 1 : value) / 255.0f;
}

float styleSaturation(int32_t style) {
    switch (style) {
        case 1:
            return 1.2f;
        case 2:
            return 1.3f;
        default:
            return 1.0f;
    }
}

float paperSaturation(int32_t type) {
    switch (type) {
        case 1:
            return 0.3f;
        case 2:
            return 0.0f;
        default:
            return 1.0f;
    }
}

float smoothstep(float value) {
    const float clamped = std::clamp(value, 0.0f, 1.0f);
    return clamped * clamped * (3.0f - 2.0f * clamped);
}

float interpolate(float from, float to, float position) {
    return from + (to - from) * smoothstep(position);
}

float rhythmicWarmth(int32_t minute) {
    struct Point {
        int32_t minute;
        float warmth;
    };
    constexpr Point points[] = {
            {0, 1.0f}, {300, 0.35f}, {420, 0.10f}, {720, 0.0f},
            {1020, 0.15f}, {1320, 1.0f}, {1440, 1.0f},
    };
    const int32_t normalized = ((minute % 1440) + 1440) % 1440;
    for (size_t i = 1; i < std::size(points); ++i) {
        if (normalized <= points[i].minute) {
            const float span = static_cast<float>(points[i].minute - points[i - 1].minute);
            const float position = static_cast<float>(normalized - points[i - 1].minute) / span;
            return interpolate(points[i - 1].warmth, points[i].warmth, position);
        }
    }
    return points[0].warmth;
}

float rhythmicCategoryGain(int32_t category) {
    switch (category) {
        case 1:  // Image apps preserve color fidelity.
            return 0.55f;
        case 2:  // Reading apps receive the full circadian correction.
            return 1.0f;
        default:
            return 0.8f;
    }
}

}  // namespace

bool RenderState::nearlyEquals(const RenderState& other, float epsilon) const {
    if (std::fabs(saturation - other.saturation) > epsilon) return false;
    for (size_t i = 0; i < matrix.size(); ++i) {
        if (std::fabs(matrix[i] - other.matrix[i]) > epsilon) return false;
    }
    return true;
}

UpdateResult ColorState::setFeature(int32_t displayId, int32_t caseId, int32_t modeId,
                                    int32_t cookie) {
    if (displayId != 0) return UpdateResult::kUnsupportedDisplay;

    const RenderState before = render();
    bool recognized = true;

    switch (caseId) {
        case 0:
        case 1:
        case 2:
            if (cookie != kExpectedCookie) return UpdateResult::kIgnored;
            colorStyle_ = caseId;
            expertModeActive_ = false;
            break;
        case 3:
            if (cookie != kExpectedCookie) return UpdateResult::kIgnored;
            eyeCareLevel_ = modeId <= 0 ? 0 : std::clamp(modeId, 50, 255);
            break;
        case 13:  // Display state changes can reset the global color transform.
        case 24:  // FPS/display transitions are emitted during wake-up.
            return UpdateResult::kReapply;
        case 23: {
            if (cookie != kExpectedCookie) return UpdateResult::kIgnored;
            const uint32_t packed = static_cast<uint32_t>(modeId);
            if ((packed & 0xff000000U) == 0xff000000U) {
                red_ = static_cast<uint8_t>((packed >> 16) & 0xffU);
                green_ = static_cast<uint8_t>((packed >> 8) & 0xffU);
                blue_ = static_cast<uint8_t>(packed & 0xffU);
            } else if (modeId == 1) {
                red_ = 255;
                green_ = 240;
                blue_ = 219;
            } else if (modeId == 2) {
                red_ = green_ = blue_ = 255;
            } else if (modeId == 3) {
                red_ = 230;
                green_ = 240;
                blue_ = 255;
            } else {
                return UpdateResult::kIgnored;
            }
            break;
        }
        case 26:
            switch (cookie) {
                case 0:
                    if (modeId < 0 || modeId > 3) return UpdateResult::kIgnored;
                    expertGamut_ = modeId;
                    break;
                case 1:
                    expertRed_ = std::clamp(modeId, 0, 255);
                    break;
                case 2:
                    expertGreen_ = std::clamp(modeId, 0, 255);
                    break;
                case 3:
                    expertBlue_ = std::clamp(modeId, 0, 255);
                    break;
                case 4:
                    expertHue_ = std::clamp(modeId, -180, 180);
                    break;
                case 5:
                    expertSaturation_ = std::clamp(modeId, -50, 100);
                    break;
                case 6:
                    expertValue_ = std::clamp(modeId, -255, 255);
                    break;
                case 7:
                    expertContrast_ = std::clamp(modeId, -100, 100);
                    break;
                case 8:
                    expertGamma_ = std::clamp(modeId, 170, 300);
                    break;
                case 9:
                    expertGamut_ = 0;
                    expertRed_ = expertGreen_ = expertBlue_ = 255;
                    expertHue_ = expertSaturation_ = expertValue_ = expertContrast_ = 0;
                    expertGamma_ = 220;
                    break;
                default:
                    return UpdateResult::kIgnored;
            }
            expertModeActive_ = true;
            break;
        case 31:
            if (cookie != kExpectedCookie || modeId < 0 || modeId > 2) {
                return UpdateResult::kIgnored;
            }
            paperColorType_ = modeId;
            break;
        case 32:
            if (cookie != kExpectedCookie || (modeId != 0 && modeId != 1)) {
                return UpdateResult::kIgnored;
            }
            trueToneEnabled_ = modeId != 0;
            break;
        case 54:
            if (modeId != 0 && modeId != 1) return UpdateResult::kIgnored;
            {
                const uint32_t packed = static_cast<uint32_t>(cookie);
                const int32_t category = static_cast<int32_t>((packed >> 16) & 0xffffU);
                const int32_t minute = static_cast<int32_t>(packed & 0xffffU);
                if (category > 2 || minute >= 1440) return UpdateResult::kIgnored;
                rhythmicCategory_ = category;
                rhythmicMinute_ = minute;
            }
            rhythmicEyeCareEnabled_ = modeId != 0;
            break;
        default:
            recognized = false;
            break;
    }

    if (!recognized) return UpdateResult::kIgnored;
    if (!before.nearlyEquals(render())) return UpdateResult::kChanged;
    // Expert controls are also used to restore state after another global
    // SurfaceFlinger color owner has replaced the transform.
    return caseId == 26 ? UpdateResult::kReapply : UpdateResult::kUnchanged;
}

RenderState ColorState::render() const {
    RenderState result;
    result.matrix = identityMatrix();

    float eyeGreen = 1.0f;
    float eyeBlue = 1.0f;
    if (eyeCareLevel_ > 0) {
        const float factor = static_cast<float>(eyeCareLevel_ - 50) / 205.0f;
        eyeGreen = 1.0f - (5.0f + factor * 25.0f) / 255.0f;
        eyeBlue = 1.0f - (20.0f + factor * 95.0f) / 255.0f;
    }

    if (rhythmicEyeCareEnabled_) {
        const float rhythmic = rhythmicWarmth(rhythmicMinute_) *
                               rhythmicCategoryGain(rhythmicCategory_);
        eyeGreen *= 1.0f - rhythmic * 0.04f;
        eyeBlue *= 1.0f - rhythmic * 0.16f;
    }

    result.matrix = channelMatrix(channelGain(red_), channelGain(green_) * eyeGreen,
                                  channelGain(blue_) * eyeBlue);
    result.saturation = paperSaturation(paperColorType_);

    if (expertModeActive_) {
        const Matrix rgb = channelMatrix(static_cast<float>(expertRed_) / 255.0f,
                                         static_cast<float>(expertGreen_) / 255.0f,
                                         static_cast<float>(expertBlue_) / 255.0f);
        const float brightness = expertValueScale(expertValue_);
        const float contrast = expertContrastScale(expertContrast_);
        result.matrix = multiply(rgb, result.matrix);
        result.matrix = multiply(hueMatrix(expertHue_), result.matrix);
        result.matrix = multiply(affineMatrix(brightness, 0.0f), result.matrix);
        result.matrix = multiply(affineMatrix(contrast, 0.5f * (1.0f - contrast)),
                                 result.matrix);
        result.matrix = multiply(gammaMatrix(expertGamma_), result.matrix);
        result.saturation *= expertGamutSaturation(expertGamut_) *
                             (1.0f + static_cast<float>(expertSaturation_) / 100.0f);
    } else {
        result.saturation *= styleSaturation(colorStyle_);
    }
    return result;
}

}  // namespace micolor
