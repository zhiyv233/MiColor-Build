#define LOG_TAG "MiColorService"

#include "micolor/displayfeature_service.h"
#include "micolor/platform_binder.h"

#include <android/binder_parcel.h>
#include <android/binder_parcel_utils.h>
#include <android/binder_status.h>
#include <android/log.h>

#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstring>

namespace micolor {
namespace {

constexpr char kDescriptor[] =
        "vendor.xiaomi.hardware.displayfeature_aidl.IDisplayFeature";
constexpr char kInstance[] =
        "vendor.xiaomi.hardware.displayfeature_aidl.IDisplayFeature/default";
constexpr char kHash[] = "e57e364757bc7b63a3a7e586585c5827115966d7";
constexpr int32_t kVersion = 2;
constexpr auto kBootReplayDuration = std::chrono::seconds(20);
constexpr auto kBootReplayInterval = std::chrono::milliseconds(50);
constexpr transaction_code_t kGetInterfaceHash = 0x00fffffe;
constexpr transaction_code_t kGetInterfaceVersion = 0x00ffffff;
constexpr size_t kMaxCallbacks = 5;

binder_status_t writeStatus(AParcel* output, binder_exception_t exception = EX_NONE) {
    AStatus* status = exception == EX_NONE ? AStatus_newOk()
                                           : AStatus_fromExceptionCode(exception);
    const binder_status_t result = AParcel_writeStatusHeader(output, status);
    AStatus_delete(status);
    return result;
}

void* onCreate(void* args) { return args; }
void onDestroy(void*) {}

binder_status_t onTransact(AIBinder* binder, transaction_code_t code, const AParcel* input,
                           AParcel* output) {
    auto* service = static_cast<DisplayFeatureService*>(AIBinder_getUserData(binder));
    return service->transact(code, input, output);
}

binder_status_t onDump(AIBinder* binder, int fd, const char**, uint32_t) {
    auto* service = static_cast<DisplayFeatureService*>(AIBinder_getUserData(binder));
    return service->dump(fd);
}

AIBinder_Class* displayFeatureClass() {
    static AIBinder_Class* clazz = [] {
        AIBinder_Class* value = AIBinder_Class_define(kDescriptor, onCreate, onDestroy, onTransact);
        AIBinder_Class_setOnDump(value, onDump);
        return value;
    }();
    return clazz;
}

}  // namespace

struct DisplayFeatureService::CallbackEntry {
    DisplayFeatureService* owner = nullptr;
    AIBinder* binder = nullptr;
    AIBinder_DeathRecipient* recipient = nullptr;
    bool alive = false;

    ~CallbackEntry() {
        if (recipient != nullptr) AIBinder_DeathRecipient_delete(recipient);
        if (binder != nullptr) AIBinder_decStrong(binder);
    }
};

DisplayFeatureService::DisplayFeatureService(std::unique_ptr<ColorBackend> backend)
    : pending_(state_.render()), backend_(std::move(backend)), worker_(&DisplayFeatureService::workerLoop, this) {
    hbm_.start();
}

DisplayFeatureService::~DisplayFeatureService() {
    {
        std::lock_guard lock(mutex_);
        stopping_ = true;
    }
    condition_.notify_one();
    worker_.join();
    hbm_.stop();
}

AIBinder* DisplayFeatureService::createBinder() {
    AIBinder* binder = AIBinder_new(displayFeatureClass(), this);
    if (binder != nullptr && AIBinder_markVintfStability != nullptr) {
        AIBinder_markVintfStability(binder);
    }
    return binder;
}

void DisplayFeatureService::scheduleApply() {
    pending_ = state_.render();
    ++desiredGeneration_;
    if (!bootReplayActive_ && bootReplayDeadline_ == std::chrono::steady_clock::time_point{}) {
        bootReplayActive_ = true;
        bootReplayDeadline_ = std::chrono::steady_clock::now() + kBootReplayDuration;
    }
    condition_.notify_one();
}

void DisplayFeatureService::workerLoop() {
    for (;;) {
        RenderState state;
        uint64_t generation = 0;
        {
            std::unique_lock lock(mutex_);
            condition_.wait(lock, [this] {
                return stopping_ || desiredGeneration_ != appliedGeneration_ || bootReplayActive_;
            });
            if (stopping_) return;

            if (desiredGeneration_ != appliedGeneration_) {
                // Bound ordinary SurfaceFlinger traffic to roughly one update per frame.
                lock.unlock();
                std::this_thread::sleep_for(std::chrono::milliseconds(16));
                lock.lock();
                if (stopping_) return;
            } else {
                condition_.wait_for(lock, kBootReplayInterval, [this] {
                    return stopping_ || desiredGeneration_ != appliedGeneration_;
                });
                if (stopping_) return;
            }

            if (bootReplayActive_ && std::chrono::steady_clock::now() >= bootReplayDeadline_) {
                bootReplayActive_ = false;
                if (desiredGeneration_ == appliedGeneration_) continue;
            }
            state = pending_;
            generation = desiredGeneration_;
            if (bootReplayActive_ && generation == appliedGeneration_) ++bootReplayCount_;
        }
        const bool applied = backend_->apply(state);
        {
            std::lock_guard lock(mutex_);
            ++applyCount_;
            if (applied) {
                appliedGeneration_ = generation;
            } else {
                ++applyFailureCount_;
            }
        }
        if (!applied) std::this_thread::sleep_for(std::chrono::milliseconds(250));
    }
}

void DisplayFeatureService::callbackDied(void* cookie) {
    auto* entry = static_cast<CallbackEntry*>(cookie);
    std::lock_guard lock(entry->owner->mutex_);
    entry->alive = false;
    if (entry->binder != nullptr) {
        AIBinder_decStrong(entry->binder);
        entry->binder = nullptr;
    }
}

void DisplayFeatureService::registerCallback(AIBinder* callback) {
    if (callback == nullptr) return;
    std::lock_guard lock(mutex_);
    for (const auto& entry : callbacks_) {
        if (entry->alive && entry->binder == callback) return;
    }

    CallbackEntry* slot = nullptr;
    for (const auto& entry : callbacks_) {
        if (!entry->alive && entry->binder == nullptr) {
            slot = entry.get();
            break;
        }
    }
    if (slot == nullptr && callbacks_.size() < kMaxCallbacks) {
        auto entry = std::make_unique<CallbackEntry>();
        entry->owner = this;
        entry->recipient = AIBinder_DeathRecipient_new(callbackDied);
        slot = entry.get();
        callbacks_.push_back(std::move(entry));
    }
    if (slot == nullptr) return;

    AIBinder_incStrong(callback);
    slot->binder = callback;
    slot->alive = true;
    if (AIBinder_linkToDeath(callback, slot->recipient, slot) != STATUS_OK) {
        slot->alive = false;
        AIBinder_decStrong(callback);
        slot->binder = nullptr;
    }
}

binder_status_t DisplayFeatureService::transact(transaction_code_t code, const AParcel* input,
                                                AParcel* output) {
    if (code == kGetInterfaceVersion) {
        binder_status_t status = writeStatus(output);
        return status == STATUS_OK ? AParcel_writeInt32(output, kVersion) : status;
    }
    if (code == kGetInterfaceHash) {
        binder_status_t status = writeStatus(output);
        return status == STATUS_OK
                       ? AParcel_writeString(output, kHash, static_cast<int32_t>(std::strlen(kHash)))
                       : status;
    }

    int32_t a = 0, b = 0, c = 0, d = 0;
    std::string text;
    binder_status_t status = STATUS_OK;
    switch (code) {
        case 1:  // oneway notifyBrightness
            status = AParcel_readInt32(input, &a);
            if (status == STATUS_OK) hbm_.onBrightness(a);
            return status;
        case 2: {  // registerCallback
            status = AParcel_readInt32(input, &a);
            AIBinder* callback = nullptr;
            if (status == STATUS_OK) status = AParcel_readStrongBinder(input, &callback);
            if (status == STATUS_OK) registerCallback(callback);
            if (callback != nullptr) AIBinder_decStrong(callback);
            return status == STATUS_OK ? writeStatus(output) : status;
        }
        case 3:  // oneway sendMessage
            status = AParcel_readInt32(input, &a);
            if (status == STATUS_OK) status = AParcel_readInt32(input, &b);
            if (status == STATUS_OK) status = ::ndk::AParcel_readString(input, &text);
            return status;
        case 4:
            status = ::ndk::AParcel_readString(input, &text);
            return status == STATUS_OK ? writeStatus(output) : status;
        case 5:
            status = AParcel_readInt32(input, &a);
            if (status == STATUS_OK) status = AParcel_readInt32(input, &b);
            return status == STATUS_OK ? writeStatus(output) : status;
        case 6:
            return writeStatus(output);
        case 7:
        case 8:
            status = AParcel_readInt32(input, &a);
            if (status == STATUS_OK) status = AParcel_readInt32(input, &b);
            if (status == STATUS_OK) status = AParcel_readInt32(input, &c);
            if (status == STATUS_OK) status = AParcel_readInt32(input, &d);
            if (status != STATUS_OK) return status;
            if (code == 7) {
                std::lock_guard lock(mutex_);
                ++requestCount_;
                const UpdateResult result = state_.setFeature(a, b, c, d);
                if (result == UpdateResult::kChanged || result == UpdateResult::kReapply) {
                    scheduleApply();
                } else if (result == UpdateResult::kUnsupportedDisplay) {
                    ++unsupportedDisplayCount_;
                } else if (result == UpdateResult::kIgnored) {
                    ++ignoredFeatureCount_;
                    lastIgnoredFeature_ = b;
                }
                hbm_.onSetFeature(b, c, d);
            }
            return writeStatus(output);
        case 9:
            status = AParcel_readInt32(input, &a);
            if (status == STATUS_OK) status = AParcel_readInt32(input, &b);
            if (status == STATUS_OK) status = AParcel_readInt32(input, &c);
            if (status == STATUS_OK) status = ::ndk::AParcel_readString(input, &text);
            if (status != STATUS_OK) return status;
            if (text.empty()) {
                std::lock_guard lock(mutex_);
                ++requestCount_;
                if (state_.setFeature(a, b, c, 255) == UpdateResult::kChanged) scheduleApply();
            }
            return writeStatus(output);
        default:
            return STATUS_UNKNOWN_TRANSACTION;
    }
}

binder_status_t DisplayFeatureService::dump(int fd) {
    std::lock_guard lock(mutex_);
    size_t liveCallbacks = 0;
    for (const auto& entry : callbacks_) liveCallbacks += entry->alive ? 1 : 0;
    dprintf(fd,
            "MiColor DisplayFeature v2\nrequests=%llu ignored=%llu unsupportedDisplays=%llu "
            "lastIgnored=%d applies=%llu failures=%llu bootReplays=%llu callbacks=%zu "
            "generation=%llu/%llu\n"
            "style=%d eyeCare=%d paperType=%d rhythmic=%d category=%d minute=%d\n"
            "expert=%d gamut=%d rgb=%d/%d/%d hsv=%d/%d/%d contrast=%d gamma=%d\n",
            static_cast<unsigned long long>(requestCount_),
            static_cast<unsigned long long>(ignoredFeatureCount_),
             static_cast<unsigned long long>(unsupportedDisplayCount_), lastIgnoredFeature_,
             static_cast<unsigned long long>(applyCount_),
             static_cast<unsigned long long>(applyFailureCount_),
             static_cast<unsigned long long>(bootReplayCount_), liveCallbacks,
            static_cast<unsigned long long>(appliedGeneration_),
            static_cast<unsigned long long>(desiredGeneration_),
             state_.colorStyle(), state_.eyeCareLevel(), state_.paperColorType(),
             state_.rhythmicEyeCareEnabled(), state_.rhythmicCategory(),
             state_.rhythmicMinute(), state_.expertModeActive(), state_.expertGamut(),
             state_.expertRed(), state_.expertGreen(), state_.expertBlue(),
             state_.expertHue(), state_.expertSaturation(), state_.expertValue(),
             state_.expertContrast(), state_.expertGamma());
    const HbmController::Snapshot hbm = hbm_.snapshot();
    dprintf(fd,
            "hbm: mode=%d connected=%d callFailed=%d hbmMode=%d brightness=%.4f "
            "brightnessMax=%.4f backlight=%d/%d lastTarget=%d writes=%llu skips=%llu "
            "lastNotifyBrightness=%d lastHdrFeature=%d/%d\n",
            static_cast<int>(hbm.mode), hbm.frameworkConnected, hbm.frameworkCallFailed,
            hbm.hbmMode, hbm.brightness, hbm.brightnessMaximum, hbm.backlight,
            hbm.maxBacklight, hbm.lastTargetBacklight,
            static_cast<unsigned long long>(hbm.writeCount),
            static_cast<unsigned long long>(hbm.skipCount), hbm.lastNotifyBrightness,
            hbm.lastHdrFeatureCase, hbm.lastHdrFeatureMode);
    return STATUS_OK;
}

const char* displayFeatureInstance() { return kInstance; }

}  // namespace micolor
