#define LOG_TAG "MiColorHbm"

#include "micolor/hbm_controller.h"
#include "micolor/platform_binder.h"

#include <android/binder_parcel.h>
#include <android/binder_status.h>
#include <android/log.h>

#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>

#include <sys/system_properties.h>

namespace micolor {
namespace {

constexpr const char* kDisplayService = "display";
constexpr const char* kDisplayDescriptor = "android.hardware.display.IDisplayManager";
constexpr transaction_code_t kGetBrightnessInfo = 0x2e;
constexpr const char* kBacklightNode = "/sys/class/backlight/panel0-backlight/brightness";
constexpr const char* kMaxBacklightNode = "/sys/class/backlight/panel0-backlight/max_brightness";
constexpr const char* kModeProp = "persist.vendor.micolor.hbm.mode";
constexpr auto kPollInterval = std::chrono::milliseconds(500);
// Idle interval when framework HBM is off. Active HBM is sampled more often so
// diagnostics reflect HDR transitions without adding another backlight owner.
constexpr auto kIdlePollInterval = std::chrono::milliseconds(1000);

// BrightnessInfo.HIGH_BRIGHTNESS_MODE_OFF (android.hardware.display.BrightnessInfo).
// Values: 0=OFF, 1=SUNLIGHT, 2=HDR.
constexpr int32_t kHbmModeOff = 0;

void* remoteCreate(void*) { return nullptr; }
void remoteDestroy(void*) {}
binder_status_t remoteTransact(AIBinder*, transaction_code_t, const AParcel*, AParcel*) {
    return STATUS_UNKNOWN_TRANSACTION;
}

AIBinder_Class* displayManagerClass() {
    static AIBinder_Class* clazz = AIBinder_Class_define(
            kDisplayDescriptor, remoteCreate, remoteDestroy, remoteTransact);
    return clazz;
}

int32_t readIntFile(const char* path, int32_t fallback) {
    FILE* file = std::fopen(path, "r");
    if (file == nullptr) return fallback;
    int32_t value = fallback;
    if (std::fscanf(file, "%d", &value) != 1) value = fallback;
    std::fclose(file);
    return value;
}

}  // namespace

HbmController::HbmController() = default;
HbmController::~HbmController() { stop(); }

void HbmController::start() {
    if (thread_.joinable()) return;
    stopping_ = false;
    thread_ = std::thread(&HbmController::loop, this);
}

void HbmController::stop() {
    if (!thread_.joinable()) return;
    stopping_ = true;
    thread_.join();
    unbindDisplayManager();
}

void HbmController::onBrightness(int32_t brightness) {
    std::lock_guard lock(mutex_);
    state_.lastNotifyBrightness = brightness;
}

void HbmController::onSetFeature(int32_t caseId, int32_t modeId, int32_t cookie) {
    (void)cookie;  // Cookie is a client-side replay token; not needed for HBM.
    // Only HDR-relevant requests are tracked; color cases are owned by ColorState.
    if (caseId != 7 && caseId < 100) return;
    std::lock_guard lock(mutex_);
    state_.lastHdrFeatureCase = caseId;
    state_.lastHdrFeatureMode = modeId;
}

HbmController::Snapshot HbmController::snapshot() const {
    std::lock_guard lock(mutex_);
    return state_;
}

HbmController::Mode HbmController::readMode() const {
    char value[PROP_VALUE_MAX] = {};
    if (__system_property_get(kModeProp, value) <= 0) return Mode::kFrameworkOwned;
    const int32_t parsed = std::atoi(value);
    switch (parsed) {
        case 0:
            return Mode::kMonitor;
        case 1:
            return Mode::kFrameworkOwned;
        case 2:
            return Mode::kForcePeak;
        default:
            return Mode::kFrameworkOwned;
    }
}

void HbmController::bindDisplayManager() {
    if (displayManager_ != nullptr && AIBinder_isAlive(displayManager_)) return;
    unbindDisplayManager();
    if (AServiceManager_checkService == nullptr) return;
    displayManager_ = AServiceManager_checkService(kDisplayService);
    if (displayManager_ == nullptr) return;
    if (!AIBinder_associateClass(displayManager_, displayManagerClass())) {
        __android_log_print(ANDROID_LOG_WARN, LOG_TAG,
                            "display service descriptor association failed");
        unbindDisplayManager();
    }
}

void HbmController::unbindDisplayManager() {
    if (displayManager_ != nullptr) {
        AIBinder_decStrong(displayManager_);
        displayManager_ = nullptr;
    }
}

bool HbmController::refreshFrameworkState() {
    bindDisplayManager();
    if (displayManager_ == nullptr) return false;

    AParcel* input = nullptr;
    AParcel* output = nullptr;
    // AIBinder_prepareTransaction writes the interface token itself (the
    // descriptor of the class attached via AIBinder_associateClass), so only
    // the method argument follows. AParcel_writeInterfaceToken is a
    // platform-only API and is NOT exported by libbinder_ndk on this device.
    binder_status_t status = AIBinder_prepareTransaction(displayManager_, &input);
    if (status == STATUS_OK) status = AParcel_writeInt32(input, 0);  // displayId 0
    if (status == STATUS_OK) {
        status = AIBinder_transact(displayManager_, kGetBrightnessInfo, &input, &output, 0);
        input = nullptr;  // AIBinder_transact takes ownership.
    }
    if (input != nullptr) AParcel_delete(input);
    if (status != STATUS_OK) {
        unbindDisplayManager();
        {
            std::lock_guard lock(mutex_);
            state_.frameworkCallFailed = true;
            if ((state_.pollCount & 0x1f) == 0) {
                __android_log_print(ANDROID_LOG_WARN, LOG_TAG,
                                    "getBrightnessInfo transact failed: %d", status);
            }
        }
        return false;
    }

    int32_t exception = 1;
    int32_t objectHeader = 0;
    float brightness = 0.0f;
    float adjustedBrightness = 0.0f;
    float minimum = 0.0f;
    float maximum = 1.0f;
    int32_t hbmMode = 0;
    float transitionPoint = 0.0f;
    int32_t maxReason = 0;
    bool overridden = false;

    if (output != nullptr) {
        if (AParcel_readInt32(output, &exception) != STATUS_OK) exception = 1;
        if (exception == 0) {
            AParcel_readInt32(output, &objectHeader);  // Parcelable presence header.
            AParcel_readFloat(output, &brightness);
            AParcel_readFloat(output, &adjustedBrightness);
            AParcel_readFloat(output, &minimum);
            AParcel_readFloat(output, &maximum);
            AParcel_readInt32(output, &hbmMode);
            AParcel_readFloat(output, &transitionPoint);
            AParcel_readInt32(output, &maxReason);
            AParcel_readBool(output, &overridden);
        }
        AParcel_delete(output);
    }

    if (exception != 0 || objectHeader == 0) {
        unbindDisplayManager();
        std::lock_guard lock(mutex_);
        state_.frameworkCallFailed = true;
        return false;
    }

    {
        std::lock_guard lock(mutex_);
        state_.frameworkConnected = true;
        state_.frameworkCallFailed = false;
        state_.hbmMode = hbmMode;
        state_.brightness = brightness;
        state_.brightnessMaximum = maximum > 0.0f ? maximum : 1.0f;
    }
    return true;
}

void HbmController::refreshBacklight() {
    std::lock_guard lock(mutex_);
    state_.maxBacklight = readIntFile(kMaxBacklightNode, -1);
    state_.backlight = readIntFile(kBacklightNode, -1);
}

void HbmController::writeBacklight(int32_t value) {
    FILE* file = std::fopen(kBacklightNode, "w");
    if (file == nullptr) {
        __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, "cannot open %s", kBacklightNode);
        return;
    }
    std::fprintf(file, "%d", value);
    std::fclose(file);
    std::lock_guard lock(mutex_);
    state_.lastTargetBacklight = value;
    ++state_.writeCount;
    __android_log_print(ANDROID_LOG_INFO, LOG_TAG, "backlight set to %d", value);
}

void HbmController::loop() {
    int32_t lastLoggedMode = -1;
    for (;;) {
        if (stopping_) return;

        const bool ok = refreshFrameworkState();
        refreshBacklight();
        const Mode mode = readMode();

        {
            std::lock_guard lock(mutex_);
            state_.mode = mode;
            ++state_.pollCount;
            if (ok && state_.hbmMode != lastLoggedMode) {
                lastLoggedMode = state_.hbmMode;
                __android_log_print(ANDROID_LOG_INFO, LOG_TAG,
                                    "HBM mode -> %d (brightness %.4f, backlight %d/%d)",
                                    state_.hbmMode, state_.brightness, state_.backlight,
                                    state_.maxBacklight);
            }
        }

        Snapshot local = snapshot();
        const int32_t target =
                chooseHbmBacklightTarget(mode, local.backlight, local.maxBacklight);
        if (target >= 0) {
            writeBacklight(target);
        } else if (mode == Mode::kForcePeak && local.backlight == local.maxBacklight &&
                   local.maxBacklight > 0) {
            std::lock_guard lock(mutex_);
            ++state_.skipCount;
        }

        // Stay responsive while HBM is active (or peak is explicitly forced),
        // and reduce binder wakeups otherwise.
        const auto interval = (mode == Mode::kForcePeak || local.hbmMode != kHbmModeOff)
                                      ? kPollInterval
                                      : kIdlePollInterval;
        const auto step = interval / 10;
        for (int i = 0; i < 10 && !stopping_; ++i) std::this_thread::sleep_for(step);
    }
}

}  // namespace micolor
