#define LOG_TAG "MiColorBackend"

#include "micolor/color_backend.h"
#include "micolor/platform_binder.h"

#include <android/binder_ibinder.h>
#include <android/binder_parcel.h>
#include <android/log.h>

#include <array>

namespace micolor {
namespace {

constexpr transaction_code_t kSetColorTransform = 1015;
constexpr transaction_code_t kSetSaturation = 1022;

void* remoteCreate(void*) { return nullptr; }
void remoteDestroy(void*) {}
binder_status_t remoteTransact(AIBinder*, transaction_code_t, const AParcel*, AParcel*) {
    return STATUS_UNKNOWN_TRANSACTION;
}

AIBinder_Class* surfaceComposerClass() {
    static AIBinder_Class* clazz = AIBinder_Class_define(
            "android.ui.ISurfaceComposer", remoteCreate, remoteDestroy, remoteTransact);
    return clazz;
}

std::array<float, 16> matrixWithSaturation(const RenderState& state) {
    const float s = state.saturation;
    const float inv = 1.0f - s;
    constexpr float lr = 0.213f;
    constexpr float lg = 0.715f;
    constexpr float lb = 0.072f;
    const std::array<float, 9> sat = {
            lr * inv + s, lg * inv, lb * inv,
            lr * inv, lg * inv + s, lb * inv,
            lr * inv, lg * inv, lb * inv + s,
    };

    // Android's mat4 storage is column-major. Compose saturation after the
    // complete color transform so affine expert controls also survive fallback.
    std::array<float, 16> out = {0.0f};
    for (size_t row = 0; row < 3; ++row) {
        for (size_t col = 0; col < 3; ++col) {
            for (size_t k = 0; k < 3; ++k) {
                out[col * 4 + row] += sat[row * 3 + k] * state.matrix[col * 4 + k];
            }
        }
        for (size_t k = 0; k < 3; ++k) {
            out[12 + row] += sat[row * 3 + k] * state.matrix[12 + k];
        }
    }
    out[15] = 1.0f;
    return out;
}

}  // namespace

SurfaceFlingerColorBackend::SurfaceFlingerColorBackend() = default;
SurfaceFlingerColorBackend::~SurfaceFlingerColorBackend() { disconnect(); }

void SurfaceFlingerColorBackend::disconnect() {
    if (surfaceFlinger_ != nullptr) {
        AIBinder_decStrong(surfaceFlinger_);
        surfaceFlinger_ = nullptr;
    }
}

bool SurfaceFlingerColorBackend::connect() {
    if (surfaceFlinger_ != nullptr && AIBinder_isAlive(surfaceFlinger_)) return true;
    disconnect();
    if (AServiceManager_checkService == nullptr) return false;
    surfaceFlinger_ = AServiceManager_checkService("SurfaceFlinger");
    if (surfaceFlinger_ == nullptr) return false;
    if (!AIBinder_associateClass(surfaceFlinger_, surfaceComposerClass())) {
        __android_log_print(ANDROID_LOG_ERROR, LOG_TAG,
                            "SurfaceFlinger descriptor association failed");
        disconnect();
        return false;
    }
    return true;
}

bool SurfaceFlingerColorBackend::transactMatrix(const std::array<float, 16>& matrix) {
    if (!connect()) return false;
    AParcel* input = nullptr;
    AParcel* output = nullptr;
    binder_status_t status = AIBinder_prepareTransaction(surfaceFlinger_, &input);
    if (status == STATUS_OK) status = AParcel_writeInt32(input, 1);
    for (float value : matrix) {
        if (status == STATUS_OK) status = AParcel_writeFloat(input, value);
    }
    if (status == STATUS_OK) {
        status = AIBinder_transact(surfaceFlinger_, kSetColorTransform, &input, &output, 0);
        input = nullptr;  // AIBinder_transact takes ownership.
    }
    if (input != nullptr) AParcel_delete(input);
    if (output != nullptr) AParcel_delete(output);
    if (status != STATUS_OK) disconnect();
    return status == STATUS_OK;
}

bool SurfaceFlingerColorBackend::transactSaturation(float saturation) {
    if (!connect()) return false;
    AParcel* input = nullptr;
    AParcel* output = nullptr;
    binder_status_t status = AIBinder_prepareTransaction(surfaceFlinger_, &input);
    if (status == STATUS_OK) status = AParcel_writeFloat(input, saturation);
    if (status == STATUS_OK) {
        status = AIBinder_transact(surfaceFlinger_, kSetSaturation, &input, &output, 0);
        input = nullptr;  // AIBinder_transact takes ownership.
    }
    if (input != nullptr) AParcel_delete(input);
    if (output != nullptr) AParcel_delete(output);
    if (status != STATUS_OK) disconnect();
    return status == STATUS_OK;
}

bool SurfaceFlingerColorBackend::apply(const RenderState& state) {
    if (!transactMatrix(state.matrix)) {
        __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, "color matrix transaction failed");
        return false;
    }
    if (transactSaturation(state.saturation)) return true;

    // Older SurfaceFlinger variants may lack 1022. Preserve the effect in 1015.
    const bool fallback = transactMatrix(matrixWithSaturation(state));
    __android_log_print(fallback ? ANDROID_LOG_WARN : ANDROID_LOG_ERROR, LOG_TAG,
                        "saturation transaction unavailable; matrix fallback %s",
                        fallback ? "applied" : "failed");
    return fallback;
}

}  // namespace micolor
