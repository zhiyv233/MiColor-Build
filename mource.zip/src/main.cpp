#define LOG_TAG "MiColorService"

#include "micolor/color_backend.h"
#include "micolor/displayfeature_service.h"
#include "micolor/platform_binder.h"

#include <android/log.h>

#include <cstdlib>
#include <memory>

int main() {
    if (ABinderProcess_setThreadPoolMaxThreadCount == nullptr ||
        ABinderProcess_joinThreadPool == nullptr || AServiceManager_addService == nullptr ||
        AIBinder_markVintfStability == nullptr) {
        __android_log_print(ANDROID_LOG_FATAL, LOG_TAG,
                            "platform Binder service APIs are unavailable");
        return EXIT_FAILURE;
    }
    ABinderProcess_setThreadPoolMaxThreadCount(4);

    auto service = std::make_unique<micolor::DisplayFeatureService>(
            std::make_unique<micolor::SurfaceFlingerColorBackend>());
    AIBinder* binder = service->createBinder();
    if (binder == nullptr) {
        __android_log_print(ANDROID_LOG_FATAL, LOG_TAG, "failed to create service binder");
        return EXIT_FAILURE;
    }

    const binder_status_t status =
            AServiceManager_addService(binder, micolor::displayFeatureInstance());
    AIBinder_decStrong(binder);
    if (status != STATUS_OK) {
        __android_log_print(ANDROID_LOG_FATAL, LOG_TAG, "service registration failed: %d", status);
        return EXIT_FAILURE;
    }

    __android_log_print(ANDROID_LOG_INFO, LOG_TAG, "registered %s",
                        micolor::displayFeatureInstance());
    ABinderProcess_joinThreadPool();
    return EXIT_FAILURE;
}
